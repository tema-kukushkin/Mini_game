using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Random_enemy : MonoBehaviour
{
  public GameObject enemyPrefab;
  	public float numEnemies;
  	public float xMin = 12F;
  	public float xMax = 85F;
  	public float yMin = 3.5F;
  	public float yMax = -4.5F;

  	void Start () {

  		GameObject newParent = GameObject.Find("0 - background");

  		for (int i = 0; i < numEnemies; i++)
  		{
  			Vector3 newPos = new Vector3(Random.Range(xMin, xMax), Random.Range(yMin, yMax), 0);
  			GameObject octo = Instantiate(enemyPrefab, newPos, Quaternion.identity) as GameObject;
  			octo.transform.parent = newParent.transform;
  		}

  	}
}
