using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
  public int hp = 2;
  public bool isEnemy = true ;
  void OnTriggerEnter2D (Collider2D collider){
    shot shot = collider.gameObject.GetComponent<shot>();
    if (shot != null){
      if (shot.isEnemyShot != isEnemy){
        hp -= shot.damage;
        Destroy(shot.gameObject);
        if (hp <=0){
          SpecialEffectsHelper.Instance.Explosion(transform.position);
          SoundEffectsHelper.Instance.MakeExplosionSound();
          Destroy(gameObject);
        }
      }
    }
  }


}
