using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyScript : MonoBehaviour
{
  private bool hasSpawn;
     private move move;
     private weapon[] weapons;
     private Collider2D coliderComponent;
     private SpriteRenderer rendererComponent;

     void Awake()
     {

         weapons = GetComponentsInChildren<weapon>();


         move = GetComponent<move>();

         coliderComponent = GetComponent<Collider2D>();

         rendererComponent = GetComponent<SpriteRenderer>();
     }


     void Start()
     {
         hasSpawn = false;


         coliderComponent.enabled = false;

         move.enabled = false;

         foreach (weapon weapon in weapons)
         {
             weapon.enabled = false;
         }
     }

     void Update()
     {

         if (hasSpawn == false)
         {
             if (rendererComponent.IsVisibleFrom(Camera.main))
             {
                 Spawn();
             }
         }
         else
         {

             foreach (weapon weapon in weapons)
             {
                 if (weapon != null && weapon.enabled && weapon.CanAttack)
                 {
                     weapon.Attack(true);
                     SoundEffectsHelper.Instance.MakeEnemyShotSound();
                 }
             }


             if (rendererComponent.IsVisibleFrom(Camera.main) == false)
             {
                 Destroy(gameObject);
             }
         }
     }


     private void Spawn()
     {
         hasSpawn = true;

         
         coliderComponent.enabled = true;
         // -- Moving
         move.enabled = true;
         // -- Shooting
         foreach (weapon weapon in weapons)
         {
             weapon.enabled = true;
         }
     }
}
