using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class weapon : MonoBehaviour
{
  public Transform shotPrefab;


 public float shootingRate = 0.5f;



 private float shootCooldown;

 void Start()
 {
   shootCooldown = 0f;
 }

 void Update()
 {
   if (shootCooldown > 0)
   {
     shootCooldown -= Time.deltaTime;
   }
 }

 public void Attack(bool isEnemy)
 {
   if (CanAttack)
   {
     shootCooldown = shootingRate;

     // Create a new shot
     var shotTransform = Instantiate(shotPrefab) as Transform;

     // Assign position
     shotTransform.position = transform.position;

     // The is enemy property
     shot shot = shotTransform.gameObject.GetComponent<shot>();
     if (shot != null)
     {
       shot.isEnemyShot = isEnemy;
     }

     // Make the weapon shot always towards it
     move move = shotTransform.gameObject.GetComponent<move>();
     if (move != null)
     {
       move.direction = this.transform.right; // towards in 2D space is the right of the sprite
     }
   }
 }

 
 public bool CanAttack
 {
   get
   {
     return shootCooldown <= 0f;
   }
 }
}
